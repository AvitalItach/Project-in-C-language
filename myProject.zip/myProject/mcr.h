#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#define MAXSIZECNTNT 2000 /*גודל מקסימלי של תוכן מאקרו*/ 
#define NAME 76 /*גודל מקסימלי של מילת מאקרו*/
#define PLACEFINALLINE 2 /*עוזר למקם את אי בתו האחרון בשורה*/
#define KEEPTOTHEAM 3 /*לשמירת מקום למילה נקודה איאמ*/
typedef struct {
    char name[NAME];
    char content[MAXSIZECNTNT];
}mkr;

int changeFiles ( FILE * f,char fileName[]);/*פרישת המאקרו*/
int search (FILE * f);/*חיפוש כמה הגדרות מאקרו יש בקובץ*/
int findMacro(char firstword[],int count);/*בדיקה האם המילה היא שם של מאקרו*/
void deleteWhitespace(char *line);/*מוחקת תוים לבנים בתחילת שורה*/
void delete_spaces(char *str);/* מקבלת מחרוזת ומוחקת כל תו שהוא רווח לפני פסיק וגם מוחקת כל תו שהוא רווח אחרי פסיק*/
char* convertTabsToSpaces(char* str);/*ממירה טאבים לרווחים ומסירה רווחים נוספים*/
/*הפונקציה לוקחת מחרוזת כארגומנט ומחזירה מחרוזת מעודכנת עם טאבים שהומרו לרווחים והוסרו רווחים נוספים.*/ 
mkr * arrMak;

