#include <stdio.h>
#include <string.h>
#define WORD1GROUPUNT3 3 /*The first action groups up to the number 3*/
#define WORD1GROUP 6 /*The number 6 from the first group of operations*/
#define WORD1GROUP7 7 /*The second set of actions from number 7*/
#define WORD1GROUP13 13/*The second set of operations up to the number 13*/
#define WORD1GROUP4 4 /*The number 4 belongs to the second group of operations*/
#define WORD1GROUP5 5 /*The number 5 belongs to the second group of actions*/
#define THELASTNUM 2 /*Position in the last number*/
#define MAXLABEL 30 /*Maximum label size*/
#define LENRGSTR 2 /*The length of the register word*/
#define NUMACT 15 /*The number of existing operations*/
#define SUZEMINNUM 2 /*Minimum number size, does not contain the scale character*/
#define SIZE 3 /*Advancing the word to the desired length*/
void checksBracketsInMIun2(char* line,int numLine);
void checksRegistInCorrectRange(char* line,int numLine);
void checksExternEntryCorrect(char* line,int numLine);
void numOpCorrect(int check, char* opsource,char* opdest,int numLine);
void correctNumInDataLine(char* line,int numLine);
void correctDataLine(char* line,int numLine);
void correctStringLine(char* line,int numLine);
void correctLabel(char* label,int numLine,int flag);
void correctNumInImedetlyMiun(char* word,int numLine,int nop);
void operatorInICLine(char* line,int numLine);/*בדיקה שיש אופרטור בשורות הנחיה*/
