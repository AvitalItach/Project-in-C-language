#include <stdio.h>
#include <ctype.h>
#include <stdlib.h> 
#define PLACEAFTERNUM 2 /*קידום לאחר המספר*/
#define NUMDIGIT 10 /*הפיכת המספר לדו ספרתי בעזרת המכפלה ב 10*/
#define ASCICODENUM 48 /*קוד האסקי של הספרה 0*/
#define EXTERN 2 /*המספר של התווית אקסטרן*/

#define FIRSTRGSTRCODE 2 /*The location of the first register encoding*/
#define SECONDRGSTRCODE 8 /*The location of the second register encoding*/
#define LABELCODE 2 /*The location of the label in the encoding*/
#define NUMCODE 2 /*The location of the number in the encoding*/

int secondpass(FILE * f);/*מעבר שני על הקובץ*/
int codsecondpass(char * word,int flag,int L);/* מעבר השני- קידוד של שורות הוראה מהמילה השניה*/
int findlbl(char firstword[]);/* מעבר שני- חיפוש תוית מסוימת במערך התויות מחזירה מיקום במערך של התוית שהשם של התוית זה המילה שהתקבלה*/

