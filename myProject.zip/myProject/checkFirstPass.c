#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "checkFirstPass.h"
#include "main.h"
struct 
{
    char *act;
}acts[]= {
    {"mov"},
    {"cmp"},
    {"add"},
    {"sub"},
    {"not"},
    {"clr"},
    {"lea"},
    {"inc"},
    {"dec"},
    {"jmp"},
    {"bne"},
    {"red"},
    {"prn"},
    {"jsr"},
    {"rts"},
    {"stop"}
};
void checksBracketsInMIun2(char* line,int numLine)/*A method that checks that there are 2 parentheses, an opening and a closing, and that there are no spaces inside the parentheses*/
{
	int i=0;
	char cpyline[LINELENGTH];
	if((strchr(line,'(')!=NULL)&&(strchr(line,')')!=NULL))
	{
		strcpy(cpyline,line);
		strtok(cpyline,"(");
		i += strlen(cpyline);
		while(line[i]!='\n')
		{
			if(isspace(line[i])!=0)
			{
				rtrnCmd = -1; 
				fprintf(stderr,"Error in line %d: there is a space inside the brackets\n",numLine);
			}
			i++;
		}
	}
	else
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: addressing method 2 does not have enough parentheses\n",numLine); 
	}
}

void checksRegistInCorrectRange(char* word,int numLine)/*A method that checks that the registers are within the normal range*/
{
	int i=0;
	if(word!=NULL)
	{
		if((strchr(word,'r')!=NULL))
		{
			for(i=0; i<strlen(word); i++)
			{
				if(word[i]=='r')
				{
					if(isspace(word[i+1])!=0)/*Checking that there is no space in the register word*/
					{
						rtrnCmd = -1;
						fprintf(stderr,"Error in line %d: there is a space instead of a number after the register.\n",numLine); 
					}
					else if((word[i+1]<'0')||(word[i+1]>'7'))/*Checking that the register is within a normal range of values*/
					{
						rtrnCmd = -1;
						fprintf(stderr,"Error in line %d: the register number is out of the range.\n",numLine);
					}
				}
			}
		}
	}
}

void checksExternEntryCorrect(char* line,int numLine)/*A method that checks that the extraneous line has a label after the word extraneous, and there is no label before the word extraneous*/
{
	char cpyline[LINELENGTH];
	char * word;
	strcpy(cpyline, line);
	strtok(cpyline," ");
	if(strchr(line,':')!=0)/*Checking that there is no label definition before the extraneous word*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Warning in line %d: there is a label before the extern word.\n",numLine);
	}
	word= strtok(NULL," ");
	strtok(word,"\n");
	correctLabel(word,numLine,0);
}

void numOpCorrect(int check, char* opsource,char* opdest,int numLine)/*A method that checks that the number of operands is correct*/
{
	int i=0, j=0;
	if(opdest!=NULL)
	{
		if(strchr(opdest,' ')!=NULL)
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: Missing comma between the operations.\n",numLine);
			return;
		}
	}
	if((check<=WORD1GROUPUNT3)||(check==WORD1GROUP))/*This is the first group of actions*/
	{
		while((opsource!=NULL)&&(isspace(opsource[i])!=0)&&(i<strlen(opsource)))/*Checking whether the first word contains only white characters*/
		{
			i++;	
		}
		while((opdest!=NULL)&&(isspace(opdest[j])!=0)&&(j<strlen(opdest))&&(opdest[j]!='\n'))/*בדיקה האם המילה השניה מכילה רק תוים לבנים*/
		{
			j++;		
		}
		if((opsource==NULL)||(opdest==NULL)||(i==strlen(opsource))||(j==strlen(opdest)))
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: The number of operators in the first group of operations is incorrect\n",numLine); 
		}
	}
	else if(((check>=WORD1GROUP7)&&(check<=WORD1GROUP13))||(check==WORD1GROUP4)||(check==WORD1GROUP5))/*there is operator 1 and it is a target operator, the second set of operations*/
	{
		while((isspace(opsource[i])!=0)&&(i<strlen(opsource)))/*Checking whether the first word contains only white characters*/
		{
			i++;	
		}
		while((isspace(opdest[j])!=0)&&(j<strlen(opdest)))/*Checking whether the second word contains only white characters*/
		{
			j++;	
		}
		if(((opsource==NULL)&&(opdest==NULL))||((i==strlen(opsource))&&(j==strlen(opdest))))
		{
			rtrnCmd = -1; 
			fprintf(stderr,"Error in line %d: The number of operators in the second group of operations is incorrect\n",numLine); 
		}
	}
	else
	{
		if(((opsource!=NULL)&&(isspace(opsource[j])!=0))||((opdest!=NULL)&&(isspace(opdest[j])!=0)))
		{
			rtrnCmd = -1; 
			fprintf(stderr,"Error in line %d: The number of operators in the third group of operations is incorrect\n",numLine); 
		}
	}
}

void correctNumInDataLine(char* line,int numLine)/*A method that checks that the numbers in the data are not decimal*/
{
	char cpyline[LINELENGTH];
	char* num;
	strcpy(cpyline,line);
	strtok(cpyline,"d");/*advancing the line after the address*/
	num = strtok(NULL," ");/*Advance the line after the .data*/
	num = strtok(NULL,",");/*Advance the line to the first number*/
	while(num!=NULL)
	{
		if(strchr(num,'.')!=0)
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: the number received is not integer\n",numLine);
		}
		num = strtok(NULL,",");
	}
}

void correctDataLine(char* line,int numLine)/*A method that checks that there is a space between the data word and the number after it, and that the commas are in a correct form*/
{
	int i=0;
	char cpyline[LINELENGTH];
    char* num;
	strcpy(cpyline,line);
	strtok(cpyline,"d");/*advancing the line after the address*/
    num= strtok(NULL," ");
	i += strlen(cpyline)+SIZE+1;/*Promoting i after the word .data*/
    num= strtok(NULL,"\n");
    if(line[i]==',')/*Checking if there is a comma before the first number*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is a comma before the first number\n",numLine);
		return; 
	}
	if(isspace(line[i])==0)/*Checking if there is a space between the data word and the number after it*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is no space between the word .data and the number\n",numLine);
		return; 
	}
	else
		i++;
	if(strstr(line,",,")!=NULL)/*Checking if there are 2 or more adjacent commas*/
	{
		rtrnCmd = -1; 
		fprintf(stderr,"Error in line %d: there is more than one separating comma\n",numLine); 
		return;
	}
	if(strchr(num,' ')!=NULL)/*Checking if a comma is missing between 2 numbers*/
	{
		rtrnCmd = -1; 
		fprintf(stderr,"Error in line %d: Missing comma between 2 operators\n",numLine);
		return; 
	}
	if(line[strlen(line)-THELASTNUM]==',')/*The test if there is a comma after the last number*/
	{
		rtrnCmd = -1; 
		fprintf(stderr,"Error in line %d: there is a comma after the last number\n",numLine); 
		return;
	}
}

void correctStringLine(char* line,int numLine)/*Checking that there are 2 dashes in the string*/
{
	int i=0;
	char cpyline[LINELENGTH];
	char* word;
	strcpy(cpyline,line);
	strtok(cpyline,".");
	word = strtok(NULL," ");
	i+=1;
	if(strchr(line,':')!=NULL)
		i += strlen(cpyline)+strlen(word);/*Promoting i after the word .string*/
	else
		i+=6;
	if(isspace(line[i])==0)/*Checking if there is a space between the word of the string and the word after it*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is no space after the word .string\n",numLine);
		return; 
	}
	i++;
	if((line[i]!='"')||(line[strlen(line)-2]!='"'))
	{
		rtrnCmd=-1; 
		fprintf(stderr,"Error in line %d: missing hyphens in the string line.\n",numLine); 
	}
}

void correctLabel(char* label,int numLine,int flag)/*Check that the label is correct*/
{
	int i=0,j;
	if(label==NULL)
	{
		if(flag==1)
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: the label is NULL\n",numLine);
			return;
		}
		else /*Checking if there is a label after entry or extern*/
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: Missing label.\n",numLine);
			return;	 
		}
	}
	if(strlen(label)>MAXLABEL)/*Checking that the length of the label is correct and less than 30*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: the label length is greater than 30\n",numLine); 
	}
	if(isalpha(label[0])==0)/*Checking that the first character in the label is a letter*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: the label name is invalid, it does not start with a letter.\n",numLine); 
	}
	if(flag==1)/*Checking label definition*/
	{
		while(label[i]!=':')
		{
			if((isalpha(label[i])==0)&&(isdigit(label[i])==0))/*Checking that the values on the label are correct*/
			{
				rtrnCmd = -1; 
				fprintf(stderr,"Error in line %d: the label does not contain valid values.\n",numLine); 
			}
			i++;
			if(isspace(label[i]))
			{
				rtrnCmd = -1; 
				fprintf(stderr,"Error in line %d: Tere is space between the label name and the colon.\n",numLine); 
				return;
			}
		}
		strtok(label,":");
		for ( j=0; j<monelbl; j++)
		{
			if (strcmp(arrlbl[j].namelbl, label)==0)/*check in the second pass - checking whether the word is the name of a symbol that is already defined in the symbol table*/
			{
				rtrnCmd = -1;
				fprintf(stderr,"Error in line %d: This label has already been defined.\n",numLine); 
				return;
			}	
		}
	}
	if(flag==0)/*Checking if it is an extern or entry label*/
	{
		while(i<strlen(label))
		{
			if((isalpha(label[i])==0)&&(isdigit(label[i])==0))/*בדיקה שהערכים בתווית תקינים*/
			{
				rtrnCmd = -1; 
				fprintf(stderr,"Error in line %d: the label does not contain valid values.\n",numLine); 
			}
			i++;
		}
	}
	if((label[0]=='r')&&(strlen(label)==LENRGSTR))/*Checking that the label name is not a register name*/
	{
		if((label[1]>='0')&&(label[1]<='7'))
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: The label name is register name.\n",numLine);
			return;
		}
	}
	
	for ( j=0; j<=NUMACT; j++)/*Checking that the label name is not an action name*/
	{
		if (strcmp(acts[j].act,label)==0)/*Checking whether the word is the name of an action*/
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: The label name is act name.\n",numLine);
			return;	
		}
	}
}

void correctNumInImedetlyMiun(char* word,int numLine,int nop)/*Check using the direct dialing method that the number appears correctly*/
{
	int i=0;
	if(nop==1)
		return;
	if(((word[i]=='r')||(isalpha(word[i]))))
	    return;
	if((word==NULL)||(strlen(word)<1))
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: The parameter is NULL.\n",numLine);
		return;
	}
	if(word[strlen(word)-1]=='#')
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is no number after the scale.\n",numLine);
		return; 
	}
	if((word[i+1]=='-')||(word[i+1]=='+'))
	{
	    i++;
	    if(strlen(word)<3)
	    {
	        rtrnCmd = -1;
		    fprintf(stderr,"Error in line %d: there is no number after the sign.\n",numLine);
		    return;
	    }
	}
	else if(strlen(word)<SUZEMINNUM)
	{
	    rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is no scale before the number.\n",numLine);
		return;
	}
	if(word[0]!='#')/*Checking that the number (the first letter) starts with a scale*/
	{
		rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: there is no scale before the number.\n",numLine); 
	}
	i++;
	if(!(isdigit(word[i])))/*Checking if the second character is a number*/
	{
		rtrnCmd = -1; 
		fprintf(stderr,"Error in line %d: the second character is not a number.\n",numLine);
		return;
	}
	i++;
	if(strchr(word,'.')!=NULL)/*Checking if the number is decimal*/
   {
       rtrnCmd = -1;
		fprintf(stderr,"Error in line %d: the number received is not integer.\n",numLine);
		return;
    }
	while((word[i]!='\n')&&(i<strlen(word)))
	{
		if(!(isdigit(word[i])))/*Checking if the character is indeed a valid number*/
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: the number is invalid, it contain a not digit character.\n",numLine);
		} 
	    i++;
	}
}

void operatorInICLine(char* line,int numLine)/*Checking that there is an operator in the prompt lines*/
{
	int i=0;
	char* word;
	char cpyline[LINELENGTH];
	strcpy(cpyline,line);
	if(strchr(line,':')!=NULL)
	{
		word = strtok(cpyline, ":");
		i += strlen(word)+1;/*i promotion after the label*/
	}
	word = strtok(NULL, " ");
	i += strlen(word);/*Promotion of an i to the place of the first operator*/
	if(strstr(word,".string")!=NULL)
	{
		while((isspace(line[i]))&&(i<strlen(line)))
		{
			i++;
		}
		if(i==strlen(line))
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: There is no character after the string.\n",numLine);
			return;
		}
	}
	if(strstr(word,".data")!=NULL)
	{
		while((isspace(line[i]))&&(i<strlen(line)))
		{
			i++;
		}
		if(i==strlen(line))
		{
			rtrnCmd = -1;
			fprintf(stderr,"Error in line %d: There is no number after the data.\n",numLine);
			return;
		}
	}
}
