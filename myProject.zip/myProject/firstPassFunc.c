#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h> 
#include "firstPassFunc.h"
#include "checkFirstPass.h"
#include "main.h"
struct 
{
    char *act;
}actType[]= {
    {"mov"},
    {"cmp"},
    {"add"},
    {"sub"},
    {"not"},
    {"clr"},
    {"lea"},
    {"inc"},
    {"dec"},
    {"jmp"},
    {"bne"},
    {"red"},
    {"prn"},
    {"jsr"},
    {"rts\n"},
    {"stop\n"}
};
strEx* arrexlbl;
int firstpass(FILE * f,int n)
{
	int L,flag=0,i=0,check,signC=0,nop=0;/*סינ סי הוא בשביל להגיד אם המספר שבמשתנה סי הוא במינוס או שלא*/
	char line[LINELENGTH],cpyline[LINELENGTH];
	char *firstword;
	char *secondword;
	char nameact[ACTNAMELEN];/*שם פעולה יכול להגיע עד לאורך של 4 תוים*/
	char *opsource;
	char *opdest;
	int c=0,moneLine=0,s=0;
	int count = searchlbl(f);
	IC=0;
	DC=0;
	monelbl=0;
	s= searchext(f);
	arrexlbl=malloc(s * sizeof(strEx));
	buildArrEx(f);/*בניית מערך התויות של האקסטרן*/
	arrlbl = realloc(arrlbl,(count * sizeof(lbl)));
	for(i=0;i<NUMLINECODE;i++)
    {
    	arrI[i]=0;
   	}
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	while((!feof(f))&&((IC+DC)<(NUMLINECODE-1)))
	{
		moneLine++;
		nop=0;
		L=0;
		flag=0;
		check=0;
		i=0;
		c=0;
		rtrnCmd=0;
		opsource="\0";
		opdest="\0";
		strcpy(cpyline,line);
		firstword = strtok(cpyline," ");
		if(strchr(line,':')!=NULL)
		{
			strcpy(cpyline,line);
            firstword = strtok(cpyline,":");
            strcat(firstword,":");
			correctLabel(firstword,moneLine,1);
			if(rtrnCmd==-1)
				intergCheck=-1;
			else/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
			{
				flag=1;	
				strcpy(cpyline,line);
				firstword=strtok(firstword,":");
			}
		}
		if((strstr(line,".data")!=NULL) || (strstr(line,".string")!=NULL))
		{	
			operatorInICLine(line,moneLine);
			if(rtrnCmd==-1)
				intergCheck=-1;
			else
			{
				if(flag==1)
				{
					addlbl (firstword,monelbl,DC,1, 0);
					monelbl++;
				}
			/*לבדוקלסדר במקרה של שורת סטרינג עם אותיות*/
				if(strstr(line,".data")!=NULL)/*השורה היא שורת הנחיה של נתונים של מספרים*/
				{	
					correctNumInDataLine(line,moneLine);
					correctDataLine(line,moneLine);
					if(rtrnCmd==-1)
						intergCheck=-1;
					else/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
					{
						while((line[i]!='\0')&&(i<strlen(line)))
						{
							if(line[i] == '-')
								signC=1;
							if(isdigit(line[i])!=0)
							{
								DC++;
								if(IC<((NUMLINECODE-1)-DC))
								{
									arrD = realloc(arrD,((DC+10)* sizeof(short)));
									arrI = realloc(arrI,(((NUMLINECODE-1)-DC+10)* sizeof(short)));
								}
								while((isdigit(line[i])!=0)&&(i<strlen(line)))/*מכניס לסי את המספר עד הפסיק*/
								{
									c=c*10;
									c+=((int)line[i])-CODEASCINUM;/*לפי קוד האסקי של ספרות*/
									i++;	
								}
								if(signC==1)
									c=c*(-1);
								arrD[DC-1] = (short)c;
								c=0;
								signC=0;
							}
							i++;
						}
					}
				}	
				else if(rtrnCmd==0)/*השורה היא שורת הנחיה של נתונים של תוים*/
				{
					i=0;
					correctStringLine(line,moneLine);
					if(rtrnCmd==-1)
						intergCheck=-1;
					if(rtrnCmd==0)/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
					{
						while((line[i]!='"')&&(i<strlen(line)))
						{
							i++;
						}
						i++;
						while((line[i]!='"')&&(i<strlen(line)))
						{
							DC++;
							arrD = realloc(arrD,((DC+10)* sizeof(short)));
							arrI = realloc(arrI,(((NUMLINECODE-1)-DC+10)* sizeof(short)));
							arrD[DC-1] = (short)line[i];/*מדליקים ביטים שמתאימים לאות*/
							i++;
						}
						DC++;/*שמירת מקום לתו סיום מחרוזת*/
						arrD[DC-1] = 0;	/*קידוד תו סיום מחרוזת*/
					}
				}
			}
		}
		else if((strstr(cpyline,".extern")!=NULL) || (strstr(cpyline,".entry")!=NULL))
		{	
			checksExternEntryCorrect(line,moneLine);/*************/
			if(rtrnCmd==-1)
				intergCheck=-1;
			else if(strstr(cpyline,".extern")!=NULL)/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
			{
				strcpy(cpyline,line);
				strtok(cpyline," ");
				secondword= strtok(NULL,"\n");/*בדיקת שגיאה: אם אין בכלל תוית אחרי הפקודה אקסטרנ*/
				if(arrlbl[monelbl].enORex!=1)
				{
					addlbl (secondword,monelbl,0,1,EXTERN);
					monelbl++;
				}
				else
				{
					intergCheck=-1;
					fprintf(stderr,"Error in line %d: The label was defined entry.\n",moneLine);
				}
			}			
		}
		else if(intergCheck==0)
		{
			if(flag==1)
			{
				addlbl (firstword,monelbl,IC,0, 0);
				monelbl++;
			}
			check=findact(cpyline,flag);
			strcpy(cpyline,line);
			if(check==-1)/*שם הפעולה אינו תקין*/
			{																											
				intergCheck=-1;
				fprintf(stderr,"Error in line %d: The action name is invalid\n",moneLine);
			}
			else
			{
				strcpy(nameact,actType[check].act);
				strcpy(cpyline,line);
				if((strchr(cpyline,'(')==NULL)&&(strchr(cpyline,')')==NULL))/*בדיקה שלא מדובר בשיטת מיעון 2*/
				{
					if((check==15)||(check==16))/**/
						nop=1;
					if(strchr(cpyline,',')!=NULL)
					{
						strtok(cpyline," ");
						if(flag==1)
							strtok(NULL," ");
    					opsource = strtok(NULL,",");
    					correctNumInImedetlyMiun(opsource,moneLine,nop);
    					opdest = strtok(NULL,"\n");
    					correctNumInImedetlyMiun(opdest,moneLine,nop);
    					addExLbl(n,arrexlbl, opsource,IC+NUMFIRSTLINE+1);
    				    addExLbl(n,arrexlbl, opdest,IC+NUMFIRSTLINE+2);/**/
    				}
    				else
    				{
    					strtok(cpyline," ");
    					if(flag==1)
							strtok(NULL," ");
    					opdest = strtok(NULL,"\n");
    					correctNumInImedetlyMiun(opdest,moneLine,nop);
    					addExLbl(n,arrexlbl, opdest,IC+NUMFIRSTLINE+1);
    				}
    				numOpCorrect(check,opsource,opdest,moneLine);
    				if(rtrnCmd==-1)
						intergCheck=-1;
					if(rtrnCmd==-1)
						intergCheck=-1;
					if((opsource!=NULL)&&(opdest!=NULL))/*כניסה להמשך המעבר רק במקרה שהמילים הם לא נאל*/
					{
						checksRegistInCorrectRange(opsource,moneLine);
						checksRegistInCorrectRange(opdest,moneLine);
						if(rtrnCmd==-1)
							intergCheck=-1;
						else/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
						{   
							L=codfirstpass(check,nameact, opsource, opdest );
							IC+=L;
						}
					}
				}
				else/*מדובר בשיטת מיעון 2*/
				{
					checksBracketsInMIun2(line,moneLine);
					if(rtrnCmd==-1)
						intergCheck=-1;
					if(rtrnCmd==0)
					{
						arrI[IC]=(arrI[IC])|(MIUN2METHOD<<PLACEMIUNOPDEST);/*מדליק את הביטים המתאימים בשביל שיטת מיעון 2*/
						arrI[IC]=(arrI[IC])|(check<<PLACEACTNAME);/*מדליק את הביטים המתאימים בשביל השם של הפעולה*/
						strtok(cpyline," ");/*לקדם את המחרוזת עד שם התוית לא כולל*/
						if(flag==1)
							strtok(NULL," ");
						firstword=strtok(NULL,"(");/*פירסט וורד הוא שם התוית עכשיו*/
						addExLbl(n,arrexlbl, firstword,IC+NUMFIRSTLINE+1);
						opsource=strtok(NULL,",");/*אופרנד 1, לבדוק שגיאה: שהאופרטור לא ריק*/
						correctNumInImedetlyMiun(opsource,moneLine,nop);
						opdest = strtok(NULL,")");/*אופרנד 2, לבדוק שגיאה: שהאופרטור לא ריק*/
						correctNumInImedetlyMiun(opdest,moneLine,nop);
						addExLbl(n,arrexlbl, opsource,IC+NUMFIRSTLINE+2);/**/
						addExLbl(n,arrexlbl, opdest,IC+NUMFIRSTLINE+3);/**/
						numOpCorrect(check,opsource,opdest,moneLine);
						checksRegistInCorrectRange(opsource,moneLine);
						checksRegistInCorrectRange(opdest,moneLine);
					}
					if(rtrnCmd==-1)
						intergCheck=-1;
					else/*כניסה להמשך המעבר רק במקרה שאין שגיאות*/
					{
						L=4;
						if((opsource[0]=='r')&&(opdest[0]=='r'))/*האופרנדים רגיסטרים ולכן צריכים מילה אחת פחות*/
							L--;
						if(opsource[0]=='r')/*אופרנד 1 רגיסטר*/
							arrI[IC]=(arrI[IC])|(MIUN3METH<<CODEPARAM2);
						else if(opsource[0]!='#')/*אופרנד 1 לא מספר אז הוא תוית*/
							arrI[IC]=(arrI[IC])|(1<<CODEPARAM2);
						if(opdest[0]=='r')/*אופרנד 2 רגיסטר*/
							arrI[IC]=(arrI[IC])|(MIUN3METH<<CODEPARAM1);
						else if(opdest[0]!='#')/*אופרנד 2 לא מספר אז הוא תוית*/
							arrI[IC]=(arrI[IC])|(1<<CODEPARAM1);					
						IC+=L;
					}
				}/*end of else- miun 2*/
			}
		}/*end of else- instruction line*/
		fgets(line, LINELENGTH, f);
	}/*end the loop of first pass*/
	if((IC+DC)>(NUMLINECODE-1))
		intergCheck = -1;
	if(intergCheck!=0)
		return intergCheck;
	for(i=0; i<monelbl; i++)/*לולאה שעוברת על מערך התויות ומעדכנת את הכתובות של התויות שבשורות הנתונים(הנחיה),לפי מספר שורות ההוראה*/
	{
		if((arrlbl[i].typelbl==1)&&(arrlbl[i].enORex==0))
			arrlbl[i].addresslbl+=(IC+NUMFIRSTLINE);
		if(arrlbl[i].typelbl==0)
			arrlbl[i].addresslbl+=NUMFIRSTLINE;
	}
	free(arrexlbl);
	return intergCheck;
}

int codfirstpass(int check, char * nameact, char * opsource, char * opdest )
{
	int L=1,i=0;
	if(opdest!=NULL)
	{
		while((isspace(opdest[i])) && (i<strlen(opdest)))/*מוחק תוים לבנים בתחילת האופרטור*/
		{
			i++;
		}
	}
	arrI[IC]=(arrI[IC])|(check<<PLACEACTNAME);/*מדליק את הביטים המתאימים בשביל השם של הפעולה*/
	if((check<=WORD1GROUPUNT3)||(check==WORD1GROUP))/*יש 2 אופרטוריםקבוצת הפעולות הראשונה*/
	{
		if(opsource[0]=='#')/*האופרטור הראשון מספר, יש 2 מילים בקוד מכיוון שזה מספר אז שיטת המיעון היא 0 ולא צריך לעדכן את המילה*/
			L+=2;	
		else if(opsource[0]=='r')/*האופרטור הראשון רגיסטר יש מילה אחת בשבילו*/
		{
			L++;
			arrI[IC]=(arrI[IC])|(MIUN3METH<<MIUNSOURCE);/*מדליק את הביטים המתאימים בשביל שיטת מיעון מקור רגיסטר*/
			if(strchr(opdest,'r')==NULL)/*האופרטור השני לא רגיסטר אז יש עוד מילה בקוד*/
				L++;
		}
		else/*האופרטור הראשון תוית יש 2 מילים בקוד*/
		{
			L+=2; /**/
			arrI[IC]=(arrI[IC])|(1<<MIUNSOURCE);/*מדליק את הביטים המתאימים בשביל שיטת מיעון מקור של תוית*/
		}
		if(opdest[i]=='r')/*האופרטור השני רגיסטר*/
			arrI[IC]=(arrI[IC])|(MIUN3METH<<MIUN2METHOD);
		else if(opdest[i]!='#')/*האופרטור השני לא מספר אז הוא תוית*/
			arrI[IC]=(arrI[IC])|(1<<MIUN2METHOD);
	}
	else if(((check>=WORD1GROUP7)&&(check<=WORD1GROUP13))||(check==WORD1GROUP4)||(check==WORD1GROUP5))/*יש אופרטור 1 והוא אופרטור יעד, קבוצת הפעולות השניה*/	
	{
		L++;
		if(opdest[i]=='r')/*האופרטור הוא רגיסטר*/
			arrI[IC]=(arrI[IC])|(MIUN3METH<<MIUN2METHOD);
		else if(opdest[i]!='#')/*האופרטור הוא לא מספר אז הוא תוית*/
			arrI[IC]=(arrI[IC])|(1<<MIUN2METHOD);	
	}
	return L;
}

void addlbl (char * firstword,int monelbl,int addresslbl,int typelbl, int enORex)
{
	strcpy(arrlbl[monelbl].namelbl,firstword);	/*בדיקת שגיאה: אם שם התווית קיים בטבלת הסמלים*/
	arrlbl[monelbl].addresslbl=addresslbl;
	arrlbl[monelbl].typelbl=typelbl;
	arrlbl[monelbl].enORex=enORex;
}

int searchlbl (FILE * f)
{
	int count=0;
	char line [LINELENGTH];
	if (f == NULL) 
	{
        fprintf(stderr,"Error: file pointer is NULL\n");
        return -1;
    }
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	while(!feof(f))
	{
		if((strstr(line,".extern")!=NULL)||(strchr(line,':')!=NULL))
			count++;
		fgets(line, LINELENGTH, f);
	}
	return count;	
}

int findact(char *cpyline,int flag)
{
	int j;
	char word[LINELENGTH]; 
	char *firstword;
	char *secondword;
	char anthrline[LINELENGTH];/*יצירת מחרוזת חדשה להעתקת שורה, מכיון שכאשר אני מבצעת את אסטיארטוק השורה שאני מקבלת תיהרס לי*/
	strcpy(anthrline,cpyline);
	secondword = strtok(NULL," ");
	firstword = strtok(anthrline," ");
	if(flag==1)
		strcpy(word,secondword);
	else
		strcpy(word,firstword);
	for ( j=0; j<=NUMNAMEACT; j++)/*הלולאה עוברת על מערך הפעולות , גי הוא 15 כגודל המערך*/
	{
		if (strcmp(actType[j].act, word)==0)/*בדיקה האם המילה היא שם של פעולה*/
			return j;
	}
	return -1;
}

void addExLbl(int n,strEx *arrexlbl, char *firstword,int address)
{
	int i;
	if(firstword==NULL)
	    return;
	for(i=0;i<n;i++)
	{
		if(strstr(firstword,arrexlbl[i].name)!=NULL)
		{
			strcpy(arrE[moneEx].name,arrexlbl[i].name);
			arrE[moneEx].address = address;
			moneEx++;
		}
	}
}

void buildArrEx(FILE *f)
{
	char line[LINELENGTH];
	char *firstword;
	char *secondword;
	int i=0;
	if (f == NULL) 
	{
        fprintf(stderr,"Error: file pointer is NULL\n");
        return ;
    }
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	firstword = strtok(line," ");
	while(!feof(f))
	{
		if(strcmp(firstword,".extern")==0)
		{
			secondword= strtok(NULL,"\n");
			strcpy(arrexlbl[i].name, secondword);
			i++;
		}
		fgets(line, LINELENGTH, f);
		firstword = strtok(line," ");
	}
}

int searchext(FILE *f)
{
	int count=0;
	char line[LINELENGTH];
	if (f == NULL) 
	{
        fprintf(stderr,"Error: file pointer is NULL\n");
        return -1;
    }
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	while(!feof(f))
	{
		if(strstr(line,".extern")!=NULL)
			count++;
		fgets(line, LINELENGTH, f);
	}
	return count;
}
