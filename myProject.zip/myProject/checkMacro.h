#include <stdio.h>
#include <string.h>
#define LENEMCR 3 /*אורך המילה אמסיאר*/
#define LENRGSTR 2 /*אורך מילת הרגיסטר*/
#define NUMACT 16 /*מספר הפעולות הקיים*/
#define LENENDMCR 6 /*אורך המילה אנדאמסיאר*/

void correctMacro(char* line,char* word,int numLine);
void correctEndmcr(char* line,int numLine);
