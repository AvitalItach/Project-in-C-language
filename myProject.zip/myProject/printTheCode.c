#include <stdio.h>
#include <string.h>
#include "printTheCode.h"

void printTheCode(char* fileName)
{
	int i, j, adress=FIRST_ADRESS;
	int num = 1 << NUM_BITS; 
	FILE * fout;
	char * cpyFileName = (char *)malloc((strlen(fileName)+KEEPTOTHEAM) * sizeof(char));
	strcpy(cpyFileName,fileName);
	strcat(cpyFileName,".ob");
	fout = fopen(cpyFileName,"w");
	fprintf(fout,"	%d %d\n",IC,DC);
	for(i = 0; i < IC; i++)/*A loop for printing the dots and dashes in the set of instructions*/
	{	
		fprintf(fout,"0%d	", adress);
		for(j = 0; j <= NUM_BITS; j++)
		{
			if((num>>j)&(arrI[i]))
				fprintf(fout,"/");
			else
				fprintf(fout,".");
		}
		fprintf(fout,"\n");
		adress+=1;
	}
	for(i = 0; i < DC; i++)/*A loop for printing the dots and dashes in the set of data*/
	{
		fprintf(fout,"0%d	", adress);
		for(j = 0; j <= NUM_BITS; j++)
		{
			if((num>>j)&(arrD[i]))
				fprintf(fout,"/");
			else
				fprintf(fout,".");
		}
		fprintf(fout,"\n");
		adress+=1;
	}
	free(cpyFileName);
}

void printExtEnt(char* fileName)
{
	FILE *fex;
	FILE *fen;
	int i,flag1=0,flag2=0;
	char * cpyFileName = (char *)malloc((strlen(fileName)+SIZE) * sizeof(char));
	strcpy(cpyFileName,fileName);
	for(i=0;i<monelbl;i++)/*A loop that opens input and external output files if necessary, the flag is so that it does not open the same file twice*/
	{
		if((flag1==0) && (arrlbl[i].enORex==1))
		{
			strcat(cpyFileName,".ent");
			fen=fopen(cpyFileName,"w");
			flag1=1;
			cpyFileName = strtok(cpyFileName,".");
		}
		if((flag2==0) && (arrlbl[i].enORex==EXTERN))
		{
			strcat(cpyFileName,".ext");
			fex=fopen(cpyFileName,"w");
			flag2=1;
			cpyFileName = strtok(cpyFileName,".");
		}
	}
	if(flag1==1)
	{
		for(i=0;i<monelbl;i++)/*A loop that writes to the entry output file the name of the labels and the address of each label that is defined as an entry*/
		{
			if(arrlbl[i].enORex==1)
				fprintf(fen,"%s\t%d\n",arrlbl[i].namelbl,arrlbl[i].addresslbl);
		}
	}
	for(i=0;i<moneEx;i++)/*A loop that writes to the external output file the locations where external characters appear*/
	{
		fprintf(fex,"%s\t%d\n",arrE[i].name,arrE[i].address);
	}
	if(flag1==1)
		fclose(fen);
	if(flag2==1)
		fclose(fex);
	free(cpyFileName);
}


