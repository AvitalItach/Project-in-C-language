#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

#include "mcr.h"
#include "firstPassFunc.h"
#include "secondPassFunc.h"
#include "printTheCode.h"
/*main.
receives files and a number of files in two variables, the function goes through the files and sends the files in order to the appropriate operations. The operations are arranging the files and extracting the macros, then a first pass that codes the first word of each line, a second pass that codes the rest of the words of the line, and finally printing the coding in dots and dashes.
The function returns -1 if errors were found in the file in one of the passes.*/
int main(int argc, char *argv[])
{
	FILE *f,*newf;
	int j=0;
	int n=0;
	int ch;/*ch is a variable to save the final value at each stage*/
	char * fileName;
	for(j=1; j<argc; j++)
	{
		fileName = (char *)malloc((strlen(argv[j])+3) * sizeof(char));
		intergCheck=0;
		strcpy(fileName,argv[j]);
		strcat(fileName,".as");
		f=fopen(fileName,"r");/*Opens the file and returns a pointer to the beginning of the file*/
		if (f == NULL) 
		{
        	fprintf(stderr,"Error: %s pointer is NULL\n",fileName);
        	return -1;
    	}
   		fseek(f,0,SEEK_SET);
		fileName = strtok(fileName,".");
    	ch = changeFiles ( f,fileName);/*Add a check that the file worked without errors before moving on*/
    	if(ch==-1)
    	{
    		return -1;
   		}
		arrI = malloc(NUMLINECODE * sizeof(short));
		arrD= malloc(1 * sizeof(short));
		arrlbl = malloc(1 * sizeof(lbl));
		arrE= malloc(NUMLINECODE*sizeof(extLbl));
    	strcat(fileName,".am");
    	newf=fopen(fileName,"r"); 
   		if (newf == NULL) 
		{
        	fprintf(stderr,"Error: newf pointer is NULL\n");
        	return -1;
    	}   
    	n= searchext(newf);
    	ch= firstpass(newf,n);
    	if(ch==-1)
    	{
    		return -1;
    	}
    	
    	fseek(newf,0,SEEK_SET);
		ch = secondpass(newf);
    	if(ch==-1)
    	{
    		return -1;
   		}
    	fileName = strtok(fileName,".");
		printTheCode(fileName);
		printExtEnt(fileName);
		moneEx=0;
		free(arrI);
		free(arrD);
		free(arrlbl);
		free(arrE);
		fclose(newf);
		fclose(f);
		free(fileName);
	}
	return 0;
}
