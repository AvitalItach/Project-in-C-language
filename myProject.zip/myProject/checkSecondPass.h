#include <stdio.h>
#include <string.h>
#define LENRGSTR 2 /*אורך המילה רגיסטר*/
void correctlabel(char* label, int numLine);
