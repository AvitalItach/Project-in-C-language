#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include "checkSecondPass.h"
#include "main.h"

void correctlabel(char* label, int numLine)/*A check labeled before the parentheses in the 2nd addressing method exists in the symbol table*/
{
	int i=0,j=0;
	if(label == NULL)/*Checking that the label is not empty*/
		return;
	if(label[strlen(label)-1]=='\n')/*Deleting a newline character if necessary*/
		strtok(label,"\n");
	if(label[0] == '#')/*A test that is not a number*/
		return;
	if((label[0] == 'r')&&(label[1] <= '7')&&(label[1] >= '0')&&(strlen(label)==LENRGSTR))/*בדיקה שלא מדובר ברגיסטר*/
		return;
	while(i < monelbl)/*Loop entry only if it is a label*/
	{
		if(strcmp(arrlbl[i].namelbl,label)!=0)
			j++;
		i++;
	}
	if(j == monelbl)
	{
		rtrnCmd = -1; 
		fprintf(stderr,"Error in line %d: no found the label in the file\n",numLine);
	}
}
