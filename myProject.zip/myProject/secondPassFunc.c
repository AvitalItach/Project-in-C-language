#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h> 
#include "secondPassFunc.h"
#include "checkSecondPass.h"
#include "main.h"

int secondpass(FILE * f)
{
	char line[LINELENGTH],cpyline[LINELENGTH]; 
	char *firstword;
	char *secondword;
	char * opsource;
	char * opdest;
	int checklbl=0,L=1,flag=0,moneLine=0;
	IC=0;
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	while((!feof(f))&&((IC+DC)<(NUMLINECODE-1)))
	{
		checklbl=0;
		flag=0;
		L=1;
		firstword="\0";
		secondword="\0";
		opsource="\0";
		opdest="\0";
		strcpy(cpyline,line);
		if(strchr(cpyline, ':')!=NULL)
			firstword=strtok(cpyline,":");
		else
			firstword = strtok(cpyline," ");
		if(strchr(line,'.')!=NULL)
		{
			if(strstr(line,".entry")!=NULL)
			{
				secondword= strtok(NULL," ");
				if(secondword[strlen(secondword)-1]=='\n')
					secondword= strtok(secondword,"\n");
				else if (secondword[strlen(secondword)-1]==' ')
					secondword= strtok(secondword," ");
				checklbl=findlbl(secondword);
				if(arrlbl[checklbl].enORex==0)
					arrlbl[checklbl].enORex=1;
				else
					intergCheck=-1;
			}
		}
		else  /*Coding of the operands from the second word (we reserved space for each line of code as the number of words it needs) according to whether it is a register, a number or a character and the types of addressing*/
		{
			if(strchr(line, ':')!=NULL)
				strtok(NULL," ");
			if((strstr(line,"stop")==NULL)&&(strstr(line,"rts")==NULL))/*Checking whether the operation does not accept parameters and if so then you do not need to code a second word*/
			{
				if((strchr(line,'(')!=NULL)&&(strchr(line,')')!=NULL))/*Checking that this is an address method 2*/
				{
					firstword = strtok(NULL,"(");/*Advance the string up to the first non-inclusive operand and that is the label*/
					correctlabel(firstword, moneLine);
					if(rtrnCmd==-1)
						intergCheck=-1;
					else
						L= codsecondpass(firstword,flag,L);/*Sending the label to the function that encodes it in the code array*/
				}
				if(rtrnCmd==0)
				{	
					opsource = strtok(NULL,",");/*Source operator, check for error: that the operator is not empty*/
					correctlabel(opsource, moneLine);
					if(rtrnCmd==-1)
						intergCheck=-1;
					else
					{
						if(strchr(line,')')!=NULL)/*Checking if it is an address method 2*/
							opdest = strtok(NULL,")");
						else
							opdest = strtok(NULL,"\n");/*target operator*/
						correctlabel(opdest, moneLine);
						if(rtrnCmd==-1)
							intergCheck=-1;
						else
						{
							if(!((opsource!=NULL)&&(opdest==NULL)))
							{
								L= codsecondpass(opsource,0,L);/*Sending the first operator to the function that checks if it is a label or register number and acts accordingly - flag 0 because it is a source operator*/
								if((opsource!=NULL)&&(opdest!=NULL))
								{
									if((strchr(opsource,'r')!=NULL)&&(strchr(opdest,'r')!=NULL))
										L--;
								}
								L= codsecondpass(opdest,1,L);/*sending the second operator to the function that checks if it is a label or register number and acts accordingly - flag 1 because it is a target operator*/
							}
							else
								L= codsecondpass(opsource,1,L);
						}
					}
				}
			}
			IC+=L;	
		}
		fgets(line, LINELENGTH, f);
		moneLine++;
	}
	if(intergCheck!=0)
	{
		return intergCheck;
	}
	return intergCheck;
}


int findlbl(char firstword[])
{
	int j;
	if(firstword[strlen(firstword)-1]=='\n')
		firstword=strtok(firstword,"\n");
	else if(firstword[strlen(firstword)-1]==' ')
		firstword=strtok(firstword," ");
	for ( j=0; j<monelbl; j++)/*Go over the label array*/
	{
		if (strcmp(arrlbl[j].namelbl, firstword)==0)/*Checking whether the word is the name of a ךשנקך*/
			return j;
	}
	return -1;
}

int codsecondpass(char * word,int flag,int L)
{
	int i=0,ilbl=0,sgineC=0;
	int c=0,num=0;
	if(flag!=1)
		arrI[IC+L]=0;
	if(word!=NULL)
	{
		while((isspace(word[i])) && (i<strlen(word)))
		{
			i++;
		}
		if(word[i]=='#')/*The operator is a number*/
		{
			if(word[i+1]=='-')
			{	
				i+=PLACEAFTERNUM;
				sgineC=1;
			}
			else if(word[i+1]=='+')
				i+=PLACEAFTERNUM;
			else
				i+=1;
			while((isdigit(word[i]))&&(i<strlen(word)))/*A loop that inserts into c the number on the word. The number can be greater than 10*/
			{ 
				c=c*NUMDIGIT;
				c += word[i]-ASCICODENUM;/*The ascii code of the number 0 is 48, to get the number itself and not its ascii code, it is necessary to download the code of the violator 0*/
				i++;
			}
			if(sgineC==1)
				c=c*(-1);	
			arrI[IC+L]= (arrI[IC+L])|(((short)c)<<NUMCODE);
			L++;
		}
		else if(word[i]=='r')/*The operator is a register*/
		{
			if(flag==1)
			{
				num=(int)word[i+1]-ASCICODENUM;
				arrI[IC+L]= (arrI[IC+L])|((short)num<<FIRSTRGSTRCODE); 
			}
			else
			{
				num=(int)word[i+1]-ASCICODENUM;
				arrI[IC+L]= (arrI[IC+L])|((short)num<<SECONDRGSTRCODE); 
			}
			L++;
		}
		else/*The operator is a label*/
		{
			ilbl=findlbl(word);
			arrI[IC+L]= arrlbl[ilbl].addresslbl;
			arrI[IC+L]=arrI[IC+L]<<LABELCODE; 
			if(arrlbl[ilbl].enORex==EXTERN)
			{
				arrI[IC+L]= (arrI[IC+L]) | (1); 
			}
			else
			{
				arrI[IC+L]= (arrI[IC+L]) | (LABELCODE);
			}
			L++;
		}
	}
	return L;
}
