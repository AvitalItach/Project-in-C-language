#include <stdio.h>
#include <ctype.h>
#include <stdlib.h> 
#define ACTNAMELEN 4 /*אורך שם פעולה*/
#define MIUN2METHOD 2 /*מספר שיטת מיעון 2*/
#define PLACEMIUNOPDEST 2 /*מיקום קידוד המילה אפדסט*/
#define CODEASCINUM 48 /*קוד האסקי של ספרות, הספרה הראשונה*/
#define NUMFIRSTLINE 100 /*מספר שורה ראשונה בקידוד*/
#define PLACEACTNAME 6 /*מיקום קידוד שם הפעולה*/
#define MIUN3METH 3 /*שיטת מיעון 3*/
#define CODEPARAM2 12 /*מיקום קידוד פרמטר 2*/
#define CODEPARAM1 10 /*מיקום קידוד פרמטר 1*/
#define WORD1GROUPUNT3 3 /*קבוצות הפעולות הראשונה עד המספר 3*/
#define WORD1GROUP 6 /*המספר 6 מקבוצת הפעולות הראשונה*/
#define MIUNSOURCE 4 /*מיקום קידוד שיטת מיעון מקור*/
#define WORD1GROUP7 7 /*קבוצת הפעולות השניה מהמספר 7*/
#define WORD1GROUP13 13/*קבוצת הפעולות השניה עד המספר 13*/
#define WORD1GROUP4 4 /*המספר 4 שייך לקבוצת הפעולות השניה*/
#define WORD1GROUP5 5 /*המספר 5 שייך לקבוצת הפעולות השניה*/
#define NUMNAMEACT 15 /*מספר שמות הפעולה הקיימים*/
#define EXTERN 2 /*המספר של התווית אקסטרן*/
#define SIZEMAXWORD 30 /*אורך מילה מקסימלי*/
typedef struct 
{
    char name[SIZEMAXWORD];
}strEx;

int firstpass(FILE * f,int n);/*מעבר ראשון על הקובץ*/
int codfirstpass(int check, char * nameact, char * opsource, char * opdest );/* מעבר הראשון- קידוד של שורות הוראה המילה הראשונה ללא שיטת מיעון 2*/
void addlbl (char * firstword,int monelbl,int addresslbl,int typelbl, int enORex);/* מעבר ראשון- מוסיף פרטי תוית למערך התויות*/
int searchlbl (FILE * f);/*בדיקה כמה תויות יש בקובץ- מעבר ראשון*/
int findact(char *cpyline,int flag);/* מעבר ראשון- חיפוש מיקום הפעולה מסוימת במערך הפעולות*/

void addExLbl(int n,strEx *arrexlbl, char *firstword,int address);/*פונקציה שמוסיפה תוית וכתובת למערך תויות האקסטרן שיודפס בסוף*/
void buildArrEx(FILE *f);/*בונה את מערך תויות האקסטרן- רק שמות התויות*/
int searchext(FILE *f);/*פונקציה שבודקת ומחזירה כמה הגדרות אקסטרן יש בקובץ*/

