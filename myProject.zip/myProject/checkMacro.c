#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "checkMacro.h"
#include "main.h"

struct 
{
    char *act;
}actsName[]= {
    {"mov"},
    {"cmp"},
    {"add"},
    {"sub"},
    {"not"},
    {"clr"},
    {"lea"},
    {"inc"},
    {"dec"},
    {"jmp"},
    {"bne"},
    {"red"},
    {"prn"},
    {"jsr"},
    {"rts"},
    {"stop"}
};

void correctMacro(char* line,char* word,int numLine)/*Checking that there are no unnecessary characters in the mcr line and that the source name is correct*/
{
	int i=0,j=0;
	while(j != LENEMCR)/*Exiting the loop only when the entire word mcr is passed*/
	{
		if(isalpha(line[i])!=0)/*Check if the character is a letter*/
			j++;
		i++;
	}
	j=0;
	while(isspace(line[i]))
	{
		i++;
	}
	i+=strlen(word);
	while(line[i] != '\n')
	{
		if(isspace(line[i]))/*Checking if the character is not a white character, in case there is a word after the word mcr*/
		{
			fprintf(stderr,"Error in line %d: There is another character in the line of the word mcr.\n",numLine);
			rtrnCmd = -1;
			return;
		}
		i++;
	}
	j=0;
	i=0;
	while(isspace(word[j]))
	{
		j++;
	}
	while(j<strlen(word))
	{
		word[i]=word[j];
		j++;
		i++;
	}
	word[i+1]='\n';
	strtok(word,"\n");
	if(strcmp(word,"extern")==0)
	{
		fprintf(stderr,"Error in line %d: The macro name is extern.\n",numLine);
		rtrnCmd = -1;
	}
	else if(strcmp(word,"entry")==0)
	{
		fprintf(stderr,"Error in line %d: The macro name is entry.\n",numLine);
		rtrnCmd = -1;
	}
	else if((word[0]=='r')&&(strlen(word)==LENRGSTR)&&(word[1]>='0')&&(word[1]<='7'))
	{
		fprintf(stderr,"Error in line %d: The macro name is register name.\n",numLine);
		rtrnCmd = -1;
	}
	else 
	{
		i=0;
		while(i!=NUMACT)
		{
			if(strcmp(word,actsName[i].act)==0)
			{
				fprintf(stderr,"Error in line %d: The macro name is act name.\n",numLine);
				rtrnCmd = -1;
				return;
			}
			else
				i++;
		}
	}
}
void correctEndmcr(char* line,int numLine)/*A check that mcr is correct without another word after it*/
{
	int i=0,j=0;
	if(strstr(line,"endmcr")!=0)
	{
		while(j != LENENDMCR)/*Exiting the loop only when the entire word endmcr is passed*/
		{
			if(isalpha(line[i])!=0)/*Check if the character is a letter*/
				j++;
			i++;	
		}
		while(line[i] != '\n')
		{
			if(!isspace(line[i]))/*Checking if the character is not a white character, in case there is a word after the word endmcr*/
			{
				fprintf(stderr,"Error in line %d: There is another character after the word endmcr\n",numLine);
				rtrnCmd = -1;
				return;
			}
			i++;
		}
	}
}
