#include <stdio.h>
#include <ctype.h>
#include <stdlib.h> 
#define LINELENGTH 81 /*Length of a line including a line break character*/
#define NUMLINECODE 155 /*Several lines of coding are possible*/
#define SIZEMAXWORD 30 /*Maximum word size*/
typedef struct 
{
    char namelbl[SIZEMAXWORD];
    int addresslbl;
	int typelbl;/*An instruction will get = 0, a directive will get = 1*/
	int enORex; /*Neither this nor this will get =0, the label is entry will get =1, the label is external will get =2*/
}lbl;

typedef struct 
{
    char name[SIZEMAXWORD];
    int address;
}extLbl;

unsigned short * arrI;/*code array*/
unsigned short * arrD;/*data set*/
lbl * arrlbl;/*Label array*/
extLbl* arrE;/*An array that contains external characters and the addresses they are mentioned in*/
int IC,DC;/*counters for each array*/
int monelbl; /*Saving number of labels*/
int moneEx; /*Saving a number extern*/
int rtrnCmd;/*Saving whether there are errors within the tests of the errors*/
int intergCheck;/*Saving whether there are errors throughout the program helps to stop the program at the end of a transition in case of errors*/
