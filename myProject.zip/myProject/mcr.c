#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h> 
#include "mcr.h"
#include "checkMacro.h"
#include "main.h"

int changeFiles ( FILE * f,char fileName[])
{
	int i=0,j=0,k=0,h=0,flag=0,moneLine=0; 
	char line[LINELENGTH],cpyline[LINELENGTH],helpline[LINELENGTH]; 
	char *firstword,*word,*newline;
	FILE * newf;
	FILE * amf;
	int count = search(f);
	char * cpyFileName = (char *)malloc((strlen(fileName)+KEEPTOTHEAM) * sizeof(char));
	strcpy(cpyFileName,fileName);
	strcat(cpyFileName,".am");
	arrMak = malloc(1 * sizeof(mkr));
	arrMak=realloc(arrMak,(count* sizeof(mkr)));/*Allocation of size to the array of macros*/
	newf = fopen("aftermacro","w");
	amf = fopen(cpyFileName,"w");
	free(cpyFileName);
	fseek(f,0,SEEK_SET);

	if (f == NULL) 
	{
        return 1;
    }
    fgets(line, LINELENGTH, f);
	while(!feof(f))/*The introduction of the macros into the array of macros*/
	{
		k++;
		strcpy(cpyline,line);
		firstword= strtok(line," ");
		if((strstr(firstword, "mcr")!=NULL)&&(strstr(firstword, "endmcr")==NULL))
		{
			word=strtok(NULL," ");/*Place in the word variable the name of the macro from the line*/
			if(word[strlen(word)-1]=='\n')
				word=strtok(word,"\n");
			correctMacro(cpyline,word,moneLine);
			if(rtrnCmd==-1)
				intergCheck=-1;
			strcpy(arrMak[j].name,word);
			strcpy(arrMak[j].content,"");
			fgets(line, LINELENGTH, f);
			strcpy(cpyline,line);
			firstword= strtok(line," ");
			while((strstr(firstword, "endmcr")==NULL) && (!feof(f)))
			{
				strcat(arrMak[j].content,cpyline);
				fgets(line, LINELENGTH, f);
				strcpy(cpyline,line);
				firstword= strtok(line," ");
			}
			correctEndmcr(cpyline,moneLine);
			if(rtrnCmd==-1)
				intergCheck=-1;
			if(arrMak[j].content[strlen(arrMak[j].content)-1]=='\n')
			{
				arrMak[j].content[strlen(arrMak[j].content)-1]='!';
				strtok(arrMak[j].content,"!");
			}
			j++;	
		}
		fgets(line, LINELENGTH, f);	
	}
	j=0;
	i=0;
	fseek(f, 0, SEEK_SET);
	fgets(line, LINELENGTH, f);
	while(!feof(f))/*Copying to a new file, deleting the unnecessary lines, putting the macros*/
	{
		h=0;
		flag=0;
		strcpy(cpyline,line);
		firstword= strtok(line," ");		
		if(cpyline[0]!=';')
		{
			if(isspace(cpyline[0])!=0)/*Examining whether the holocaust is white characters*/
			{
				i=1;
				while((isspace(cpyline[i])) && (i<strlen(cpyline)))
				{
					i++;	
				}
				if(i!=strlen(cpyline))
				{
					strcpy(line,"");
					while(i!=strlen(cpyline))
					{
						helpline[h]=cpyline[i];/*Copies the line without the spaces at the beginning to an auxiliary line*/
						i++;
						h++;
					}
					strtok(helpline,"\n");
					strcat(helpline,"\n");
					strcpy(line,helpline);
					strcpy(cpyline,line);
					firstword= strtok(line," ");
				}
				else
					flag=1;
			}
			if((flag==0)&&(strstr(firstword, "mcr")!=NULL)&&(strstr(firstword, "endmcr")==NULL))/*Checking whether the line is a macro definition*/
			{
				while((strstr(firstword, "endmcr")==NULL)&&(!feof(f)))
				{
					fgets(line, LINELENGTH, f);
					strcpy(cpyline,line);
					firstword= strtok(line," ");
				}

			}
			else if(flag==0)
			{
				strcpy(line,cpyline);
				k=0;
				i=0;
				while((firstword[strlen(firstword)-PLACEFINALLINE]!='\n')&&(k<strlen(cpyline)))
				{
					if (k==0)
						firstword=strtok(line," ");
					else
						firstword=strtok(NULL," ");
					k+=strlen(firstword)+1;
					if(!isspace(firstword[0]))
					{
						if(findMacro(firstword,count)==-1)/*Checking whether the word is not the name of a macro*/
						{	
							fprintf(newf,"%s ",firstword);	
						}
						else
						{
							j=findMacro(firstword,count);
							fprintf(newf,"%s",arrMak[j].content);
							fprintf(newf, "\n");									
						}
					}
				}
				fprintf(newf,"\n");
			}
		}
		fgets(line, LINELENGTH, f);
		moneLine++;
	}
	fclose(newf);
	newf = fopen("aftermacro","r");
	fgets(line, LINELENGTH, newf);
	while(!feof(newf))/*Copy to a new file, without unnecessary white characters*/
	{
		deleteWhitespace(line);
		newline =convertTabsToSpaces(line);
		newline =convertTabsToSpaces(newline);
		delete_spaces(newline);
		fprintf(amf,"%s",newline);
		fgets(line, LINELENGTH, newf);
	}
	fclose(amf);
	free(arrMak);
	remove("aftermacro");
	if(intergCheck!=0)
	{
		return intergCheck;
	}
	return 0;
}

int findMacro(char firstword[],int count)
{
	int j;
	if(firstword[strlen(firstword)-1]=='\n')
		firstword=strtok(firstword,"\n");
	for ( j=0; j<count; j++)
	{
		if (strcmp(arrMak[j].name, firstword)==0)/*Checking if the word is the name of a macro*/
		{
			return j;	
		}
	}
	return -1;
}

int search (FILE * f)
{
	int count=0;
	char * firstword;
	char  line[LINELENGTH];
	if (f == NULL) 
	{
        	return -1;
    }
	fseek(f,0,SEEK_SET);
	fgets(line, LINELENGTH, f);
	firstword= strtok(line," ");
	while(!feof(f))
	{
		if((strstr(firstword, "mcr")!=NULL)&&(strstr(firstword, "endmcr")==NULL))
			count++;
																
		fgets(line, LINELENGTH, f);
		firstword= strtok(line," ");
	}

	return count;	
}

char* convertTabsToSpaces(char* str)
{
 	int i=0, j=0;
	int len = strlen(str);
 	char* result1;
	char * result2;
 	if(strchr(str,'"')!=NULL)
 	{
 		result1 = (char*)malloc(len * sizeof(char));
 		while(str[i]!='"')
 		{
 			if (str[i] == '\t') /*You deleted a tab and put a space in its place*/
 				result1[j++] = ' ';
 			else if ((str[i] == ' ') && ((i == 0) || (str[i - 1] != ' ')))/*Deleting a white character if there is a white character before it*/
 				result1[j++] = str[i];
 			else if (str[i] != ' ')/*Copy the character if it is not a white character*/
 		   		result1[j++] = str[i];
 			i++;
 		}
 		while(i<len)
 		{
 		   	result1[j++] = str[i];
 			i++;
 		}
 		result1[j] = '\0';
 		return result1;
 	}
 	result2 = (char*)malloc(len * sizeof(char));
 	for (i = 0, j = 0; i < len; i++) 
 	{
 		if (str[i] == '\t') /*You deleted a tab and put a space in its place*/
 			result2[j++] = ' ';
 		else if ((str[i] == ' ') && ((i == 0) || (str[i - 1] != ' ')))/*Deleting a white character if there is a white character before it*/
 			result2[j++] = str[i];
 		else if (((str[i] == ' ')||(str[i] == '\t')) && ((i+1)==len))/*Deleting a white character at the end of a line*/
 		{
 			result2[j++] = '\n';
 			i=len+1;
 		}
 		else if (str[i] != ' ')/*Copy the character if it is not a white character*/
 		   result2[j++] = str[i];
 	}
 	result2[j] = '\0';
 	return result2;
}
void delete_spaces(char *str)
{
    int i, j, len;
    len = strlen(str);
    if(strchr(str,'(')!=NULL)
    	return;
    for (i = 0; i < len; i++) 
	{
        if (str[i] == ' ' && str[i+1] == ',') 
        {
            for (j = i; j < len; j++) 
            {
                str[j] = str[j+1];
            }
            len--;
            i--;
        }
        else if (str[i] == ',' && str[i+1] == ' ') 
        {
            for (j = i+1; j < len; j++) 
            {
                str[j] = str[j+1];
            }
            len--;
        }
    }
}
void deleteWhitespace(char *line)
{
	int i = 0;
	char *dest,*src;
 	while (isspace(line[i]))
	{
	 	i++;
 	}
 	if (i > 0) 
 	{
 		dest = line;
 		src = line + i;
 		while (*src != '\0') 
 		{
 			*dest++ = *src++;
		}
 		*dest = '\0';
 	}
 	i=strlen(line)-PLACEFINALLINE;
	while ((isspace(line[i]))&&(i>0))/*Deleting white characters at the end of a line*/
	{
		i--;
	}
	if(i>0)
	{
		line[i+1]='\n';
		strtok(line,"\n");
		strcat(line,"\n");
	}
}
