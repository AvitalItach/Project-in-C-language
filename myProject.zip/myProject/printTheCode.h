#include <stdio.h>
#include <ctype.h>
#include <stdlib.h> 
#include "main.h"

#define FIRST_ADRESS 100 /*המיקום של הכתובת הראשונה שתודפס*/
#define NUM_BITS 13 /*מספר הביטים*/
#define EXTERN 2 /*המספר של התווית אקסטרן*/
#define SIZE 4 /*הגודל המבוקש*/
#define KEEPTOTHEAM 3 /*לשמירת מקום למילה נקודה איאמ*/
void printTheCode(char* fileName);/*פונקציה להדפסת המערכים לקובץ*/
void printExtEnt(char* fileName);/*פונקציה להדפסת התויות לקבצי האקסטרן והאנטרי*/


